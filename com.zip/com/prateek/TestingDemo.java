package com.prateek;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestingDemo {
	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		String s1 = "";
		
		/*Map<String,Object> encryptedPanJson = new ObjectMapper().readValue("{ \"pan_enc\": \"encr12345\", \"pan_iV\": \"pan1234\", \"cvv\": \"Y\", \"CNF\": \"cnf787\", \"Country\": \"US\" },"
				+ "{ \"pan_enc\": \"encr123456\", \"pan_iV\": \"pan12346\", \"cvv\": \"Y\", \"CNF\": \"cnf7876\", \"Country\": \"USA\" }",Map.class);
		System.out.println(encryptedPanJson.size());*/
		
		List<Map<String,Object>> encryptedPanJson = (List<Map<String, Object>>) new ObjectMapper().readValue("{ \"pan_enc\": \"encr12345\", \"pan_iV\": \"pan1234\", \"cvv\": \"Y\", \"CNF\": \"cnf787\", \"Country\": \"US\" }",Map.class);
		System.out.println(encryptedPanJson);
	}
}
