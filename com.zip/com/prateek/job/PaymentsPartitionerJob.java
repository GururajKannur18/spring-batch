package com.prateek.job;


import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.partition.PartitionHandler;
import org.springframework.batch.core.partition.support.TaskExecutorPartitionHandler;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.PagingQueryProvider;
import org.springframework.batch.item.database.support.SqlPagingQueryProviderFactoryBean;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.jdbc.core.BeanPropertyRowMapper;

import com.prateek.callback.PaymentsTasklet;
import com.prateek.model.Payments;
import com.prateek.partitioner.RangePartitioner;
import com.prateek.processor.PaymentProcessor;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@EnableBatchProcessing
public class PaymentsPartitionerJob {
	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Autowired
	private DataSource dataSource;

	@Bean
	public SimpleAsyncTaskExecutor taskExecutor() {
		return new SimpleAsyncTaskExecutor();
	}

	@Bean
	@StepScope
	public RangePartitioner rangePartitioner() {
		return new RangePartitioner();
	}

	@Bean
	public PaymentsTasklet paymentsTasklet() {
		return new PaymentsTasklet();
	}

	@Bean
	@StepScope
	public PaymentProcessor slaveProcessor(@Value("#{stepExecutionContext[name]}") String name) {
		log.info("********called slave processor **********");
		PaymentProcessor paymentProcessor = new PaymentProcessor();
		paymentProcessor.setThreadName(name);
		return paymentProcessor;
	}

	
	@Bean
	@StepScope
	public FlatFileItemWriter<Payments> slaveWriter(@Value("#{stepExecutionContext[fromId]}") final String fromId,
			@Value("#{stepExecutionContext[toId]}") final String toId) {
		
		FlatFileItemWriter<Payments> reader = new FlatFileItemWriter<>();
		reader.setResource(new FileSystemResource("csv/payments.processed" + fromId + "-" + toId + ".csv"));
		reader.setAppendAllowed(true);
		reader.setLineAggregator(new DelimitedLineAggregator<Payments>() {
			{
				setDelimiter(",");
				setFieldExtractor(new BeanWrapperFieldExtractor<Payments>() {
					{
						setNames(new String[] { "customerNumber", "checkNumber", "paymentDate", "amount" });
					}
				});
			}
		});
		return reader;
	}

	@Bean
	@StepScope
	public JdbcPagingItemReader<Payments> slaveReader(@Value("#{stepExecutionContext[fromId]}") final String fromId,
			@Value("#{stepExecutionContext[toId]}") final String toId,
			@Value("#{stepExecutionContext[name]}") final String name) {

		// Bean Property Row Mapper
		BeanPropertyRowMapper<Payments> propertyRowMapper = new BeanPropertyRowMapper<>();
		propertyRowMapper.setMappedClass(Payments.class);

		log.info("slaveReader start " + fromId + " " + toId);

		// Jdbc Paging Item Reader
		JdbcPagingItemReader<Payments> reader = new JdbcPagingItemReader<>();
		reader.setDataSource(dataSource);
		reader.setQueryProvider(queryProvider());

		// Set the Parameter values
		Map<String, Object> parameterValues = new HashMap<>();
		parameterValues.put("fromId", fromId);
		parameterValues.put("toId", toId);
		log.info("Parameter Value " + name + " " + parameterValues);

		reader.setParameterValues(parameterValues);
		reader.setPageSize(1000);
		reader.setRowMapper(propertyRowMapper);
		return reader;
	}

	private PagingQueryProvider queryProvider() {
		log.info("queryProvider start ");
		SqlPagingQueryProviderFactoryBean provider = new SqlPagingQueryProviderFactoryBean();
		provider.setDataSource(dataSource);
		provider.setSelectClause("SELECT customerNumber, checkNumber, paymentDate, amount ");
		provider.setFromClause("FROM payments ");
		provider.setWhereClause("WHERE customerNumber >= :fromId AND customerNumber <= :toId ");
		provider.setSortKey("customerNumber");
		try {
			System.out.println("=================> RESULT :: "+provider.getObject());
			return provider.getObject();
		} catch (Exception e) {
			log.error("ERROR IN queryProvider() "+e.getMessage());
		}
		return null;
	}

	@Bean(name = "slave")
	public Step slave() {
		log.info("...........called slave .........");
		return stepBuilderFactory.get("slave").<Payments, Payments>chunk(100)
				.reader(slaveReader(null, null, null))
				.processor(slaveProcessor(null))
				.writer(slaveWriter(null, null))
				.build();
	}



	@Bean
	public PartitionHandler masterSlaveHandler() {
		TaskExecutorPartitionHandler handler = new TaskExecutorPartitionHandler();
		handler.setGridSize(10);
		handler.setTaskExecutor(taskExecutor());
		handler.setStep(slave());
		try {
			handler.afterPropertiesSet();
		} catch (Exception e) {
			log.error("masterSlaveHandler :: "+e.getMessage());
		}
		return handler;
	}

	@Bean
	public Step masterStep() {
		return stepBuilderFactory.get("masterStep")
				.partitioner(slave().getName(), rangePartitioner())
				.partitionHandler(masterSlaveHandler())
				.build();
	}

	@Bean
	public Step step2() {
		return stepBuilderFactory.get("step2").tasklet(paymentsTasklet()).build();
	}

	@Bean
	public Job PartitionJob() {
		return jobBuilderFactory
				.get("partitionJob")
				.incrementer(new RunIdIncrementer())
				.start(masterStep())
				.next(step2())
				.build();
	}
}
