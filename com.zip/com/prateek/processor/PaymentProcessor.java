package com.prateek.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.prateek.model.Payments;

import lombok.Data;

@Component
@Data
public class PaymentProcessor implements ItemProcessor<Payments, Payments> {
	private String threadName;

	@Override
	public Payments process(Payments item) throws Exception {
		System.out.println(threadName + " processing : " + item.getCustomerNumber() + " : " + item.getAmount());
		return item;
	}
}
